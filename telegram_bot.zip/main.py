import requests
import time

# توکن ربات
TOKEN = "8264639158:AAEEXtk27NGTjhDJHJZL-hM9nRKZ3nnqs0A"
# آیدی گروه
CHAT_ID = "-1002733217001"

# آدرس API تلگرام
URL = f"https://api.telegram.org/bot{TOKEN}"

def send_message(text):
    requests.post(f"{URL}/sendMessage", data={"chat_id": CHAT_ID, "text": text})

def get_updates(offset=None):
    params = {"timeout": 100, "offset": offset}
    res = requests.get(f"{URL}/getUpdates", params=params)
    return res.json()

def main():
    last_update_id = None
    while True:
        updates = get_updates(last_update_id)
        if "result" in updates:
            for update in updates["result"]:
                last_update_id = update["update_id"] + 1
                if "message" in update:
                    text = update["message"].get("text", "")
                    send_message(text)
        time.sleep(1)

if __name__ == "__main__":
    main()
